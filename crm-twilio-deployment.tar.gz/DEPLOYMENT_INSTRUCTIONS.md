# 🚀 CRM Twilio - Deployment Instructions

## 📋 Deployment Package Contents

This deployment package contains all necessary files for the CRM Twilio production deployment:

```
dist/
├── backend/                 # Node.js backend application
├── frontend/               # Web frontend interface
├── logs/                   # Application logs directory
├── .env                    # Production environment configuration
├── package.json            # Node.js dependencies
├── start-server.sh         # Server startup script
├── README.md               # Project documentation
├── MANUAL_DE_USO.md        # User manual in Spanish
├── config.php              # PHP configuration
└── status.php              # Server status check
```

## 🎯 Target Server Configuration

- **Host**: `access-5018020518.webspace-host.com`
- **User**: `a951193`
- **Target Path**: `/home/a951193/crm-twilio`
- **Port**: `3001`

## 📤 Deployment Methods

### Method 1: Manual Upload via Control Panel

1. **Compress the deployment package**:
   ```bash
   tar -czf crm-twilio-deployment.tar.gz *
   ```

2. **Upload via hosting control panel**:
   - Access your hosting control panel
   - Navigate to File Manager
   - Upload `crm-twilio-deployment.tar.gz` to `/home/a951193/`
   - Extract the archive to `/home/a951193/crm-twilio/`

3. **Set permissions and start**:
   ```bash
   chmod +x /home/a951193/crm-twilio/start-server.sh
   cd /home/a951193/crm-twilio
   ./start-server.sh
   ```

### Method 2: SFTP Upload

1. **Using SFTP client**:
   ```bash
   sftp a951193@access-5018020518.webspace-host.com
   cd /home/a951193
   mkdir crm-twilio
   cd crm-twilio
   put -r dist/* .
   quit
   ```

2. **Start the application**:
   ```bash
   ssh a951193@access-5018020518.webspace-host.com
   cd /home/a951193/crm-twilio
   chmod +x start-server.sh
   ./start-server.sh
   ```

### Method 3: Direct SSH Deployment

1. **Connect to server**:
   ```bash
   ssh a951193@access-5018020518.webspace-host.com
   ```

2. **Create directory and upload files**:
   ```bash
   mkdir -p /home/a951193/crm-twilio
   cd /home/a951193/crm-twilio
   # Upload files using your preferred method
   ```

3. **Start application**:
   ```bash
   chmod +x start-server.sh
   ./start-server.sh
   ```

## ⚙️ Environment Configuration

Before deployment, ensure the `.env` file contains the correct production values:

```env
# Database Configuration
DB_HOST=db5018065428.hosting-data.io
DB_NAME=dbu2025297
DB_USER=dbu2025297
DB_PASSWORD=your_actual_database_password

# Twilio Configuration
TWILIO_ACCOUNT_SID=your_actual_twilio_sid
TWILIO_AUTH_TOKEN=your_actual_twilio_token

# Gemini AI Configuration
GEMINI_API_KEY=your_actual_gemini_api_key
```

## 🔍 Verification Steps

1. **Check application status**:
   ```bash
   curl https://access-5018020518.webspace-host.com:3001/api/status
   ```

2. **Monitor logs**:
   ```bash
   tail -f /home/a951193/crm-twilio/logs/app.log
   ```

3. **Check running processes**:
   ```bash
   ps aux | grep node
   ```

4. **Test web interface**:
   - Open: `https://access-5018020518.webspace-host.com:3001`

## 🛠 Troubleshooting

### Application Won't Start
- Check logs: `cat logs/app.log`
- Verify Node.js is installed: `node --version`
- Check port availability: `netstat -tulpn | grep 3001`

### Database Connection Issues
- Verify database credentials in `.env`
- Test database connectivity
- Check firewall settings

### Permission Issues
- Ensure proper file permissions: `chmod +x start-server.sh`
- Check directory ownership: `chown -R a951193:a951193 /home/a951193/crm-twilio`

## 📞 Support

For deployment assistance, refer to:
- `MANUAL_DE_USO.md` - User manual in Spanish
- `README.md` - Technical documentation
- Application logs in `logs/app.log`

## 🎉 Post-Deployment

After successful deployment:
1. ✅ Application accessible at: `https://access-5018020518.webspace-host.com:3001`
2. ✅ Admin users can login with provided credentials
3. ✅ Twilio integration ready for calls and SMS
4. ✅ AI analysis features available
5. ✅ Contact management system operational

---

*Deployment package generated: December 2024*  
*Version: 3.0.0*
