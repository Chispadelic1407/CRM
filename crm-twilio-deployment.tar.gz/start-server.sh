#!/bin/bash

# CRM Twilio Production Server Startup Script
echo "🚀 Starting CRM Twilio Production Server..."

# Navigate to application directory
cd /home/a951193/crm-twilio

# Install dependencies if needed
if [ ! -d "node_modules" ]; then
    echo "📦 Installing Node.js dependencies..."
    npm install --production
fi

# Stop any existing processes
echo "🛑 Stopping existing processes..."
pkill -f "node.*server.js" || true

# Create logs directory if it doesn't exist
mkdir -p logs

# Start the application
echo "▶️ Starting application..."
nohup node backend/server.js > logs/app.log 2>&1 &

# Wait for startup
sleep 3

# Check if application is running
if pgrep -f "node.*server.js" > /dev/null; then
    echo "✅ Application started successfully!"
    echo "🌐 Application URL: https://access-5018020518.webspace-host.com:3001"
    echo "📋 Process ID: $(pgrep -f 'node.*server.js')"
    echo "📝 Logs: tail -f logs/app.log"
else
    echo "❌ Failed to start application. Check logs:"
    tail -20 logs/app.log
    exit 1
fi

echo "🎉 Deployment completed successfully!"
